// PSD to Figma — Mplanit 내부용
// UI(ui.html)에서 파싱한 스펙 + 레이어 PNG를 받아 Figma 노드로 재조립한다.

figma.showUI(__html__, { width: 400, height: 580 });

const BLEND = {
  "normal": "NORMAL", "pass through": "PASS_THROUGH", "multiply": "MULTIPLY",
  "screen": "SCREEN", "overlay": "OVERLAY", "lighten": "LIGHTEN", "darken": "DARKEN",
  "soft light": "SOFT_LIGHT", "hard light": "HARD_LIGHT",
  "color dodge": "COLOR_DODGE", "color burn": "COLOR_BURN",
  "linear dodge": "LINEAR_DODGE", "linear burn": "LINEAR_BURN",
  "difference": "DIFFERENCE", "exclusion": "EXCLUSION",
  "hue": "HUE", "saturation": "SATURATION", "color": "COLOR", "luminosity": "LUMINOSITY"
};

let pending = null; // { spec, options, images: Map<key, Uint8Array> }
let fontIndex = null; // family(lower) -> Set(styles)

async function buildFontIndex() {
  if (fontIndex) return fontIndex;
  const fonts = await figma.listAvailableFontsAsync();
  fontIndex = new Map();
  for (const f of fonts) {
    const k = f.fontName.family.toLowerCase();
    if (!fontIndex.has(k)) fontIndex.set(k, { family: f.fontName.family, styles: new Set() });
    fontIndex.get(k).styles.add(f.fontName.style);
  }
  return fontIndex;
}

// PSD 폰트명 → Figma 폰트 매핑 (정확일치 → 부분일치 → 폴백 체인)
const FALLBACK_FAMILIES = ["Pretendard", "Noto Sans KR", "Inter"];
function guessStyle(psdFont, styles) {
  const n = (psdFont || "").toLowerCase();
  const want = [];
  if (/black|heavy|eb|extrabold/.test(n)) want.push("Black", "Heavy", "ExtraBold", "Extra Bold", "Bold");
  else if (/bold|bd/.test(n)) want.push("Bold", "SemiBold", "Semi Bold", "Medium");
  else if (/medium|md/.test(n)) want.push("Medium", "Regular");
  else if (/light|lt/.test(n)) want.push("Light", "Regular");
  else want.push("Regular", "Medium");
  for (const w of want) if (styles.has(w)) return w;
  return styles.values().next().value; // 첫 스타일
}
function heavyStyle(styles, fauxBold, sizePx) {
  // 대체 시 두께 추정: 가짜굵게 → 최상급, 대형 타이틀(>=36px) → Bold급, 그 외 null(이름 기반 유지)
  let want = null;
  if (fauxBold) want = ["Black", "Heavy", "ExtraBold", "Extra Bold", "Bold"];
  else if (sizePx >= 60) want = ["ExtraBold", "Extra Bold", "Bold", "SemiBold", "Semi Bold"];
  else if (sizePx >= 36) want = ["Bold", "SemiBold", "Semi Bold", "Medium"];
  if (!want) return null;
  for (const w of want) if (styles.has(w)) return w;
  return null;
}
async function resolveFont(psdFont, sizePx, fauxBold) {
  const idx = await buildFontIndex();
  const n = (psdFont || "").toLowerCase().replace(/[-_\s]/g, "");
  // 1) 정확/포함 일치 — 원본 폰트가 있으면 이름 기반 스타일 유지
  for (const [k, v] of idx) {
    const kk = k.replace(/[-_\s]/g, "");
    if (kk === n || (n.length > 3 && (kk.includes(n) || n.includes(kk)))) {
      const st = (fauxBold && heavyStyle(v.styles, true, 0)) || guessStyle(psdFont, v.styles);
      return { family: v.family, style: st, substituted: false };
    }
  }
  // 2) 폴백 체인 — 이름에 두께 단서가 없으면 크기·가짜굵게로 추정
  for (const fam of FALLBACK_FAMILIES) {
    const v = idx.get(fam.toLowerCase());
    if (v) {
      const named = /black|heavy|eb|extrabold|bold|bd|medium|md|light|lt/.test((psdFont || "").toLowerCase());
      const st = (!named && heavyStyle(v.styles, fauxBold, sizePx || 0)) || (fauxBold && heavyStyle(v.styles, true, 0)) || guessStyle(psdFont, v.styles);
      return { family: v.family, style: st, substituted: true };
    }
  }
  return { family: "Inter", style: fauxBold || (sizePx || 0) >= 36 ? "Bold" : "Regular", substituted: true };
}

function rgb01(c) { return { r: (c.r || 0) / 255, g: (c.g || 0) / 255, b: (c.b || 0) / 255 }; }

async function buildLayer(l, parent, ctx) {
  let node = null;
  if (l.kind === "group") {
    const children = [];
    for (const c of l.children || []) {
      const n = await buildLayer(c, parent, ctx);
      if (n) children.push(n);
    }
    if (children.length) {
      node = figma.group(children, parent);
      node.name = l.name || "그룹";
      if (l.blend && BLEND[l.blend] && BLEND[l.blend] !== "PASS_THROUGH") node.blendMode = BLEND[l.blend];
    }
  } else if (l.kind === "text" && l.text && ctx.options.textAsText) {
    const font = await resolveFont(l.text.font, (l.text.size || 16) * (l.text.scale || 1), !!l.text.fauxBold);
    await figma.loadFontAsync({ family: font.family, style: font.style });
    const t = figma.createText();
    parent.appendChild(t);
    t.fontName = { family: font.family, style: font.style };
    t.characters = l.text.content || "";
    if (l.text.size) t.fontSize = Math.max(1, l.text.size * (l.text.scale || 1));
    if (typeof l.text.tracking === "number") t.letterSpacing = { unit: "PERCENT", value: l.text.tracking / 10 };
    if (l.text.color) t.fills = [{ type: "SOLID", color: rgb01(l.text.color) }];
    const alignMap = { left: "LEFT", center: "CENTER", right: "RIGHT" };
    if (l.text.align && alignMap[l.text.align]) t.textAlignHorizontal = alignMap[l.text.align];
    t.x = l.x; t.y = l.y;
    t.name = l.name || t.characters.slice(0, 20);
    if (l.text.rot) t.rotation = -l.text.rot;
    if (l.fx) {
      const effs = [];
      const toEff = (f, type) => {
        const rad = (f.angle || 0) * Math.PI / 180;
        return { type, visible: true, blendMode: "NORMAL",
          color: { ...rgb01(f.color), a: Math.min(1, f.opacity != null ? f.opacity : 0.6) },
          offset: { x: -Math.cos(rad) * (f.distance || 0), y: Math.sin(rad) * (f.distance || 0) },
          radius: f.size || 0, spread: 0 };
      };
      if (l.fx.dropShadow) effs.push(toEff(l.fx.dropShadow, "DROP_SHADOW"));
      if (l.fx.outerGlow) effs.push(toEff({ ...l.fx.outerGlow, angle: 0, distance: 0 }, "DROP_SHADOW"));
      if (l.fx.innerShadow) effs.push(toEff(l.fx.innerShadow, "INNER_SHADOW"));
      if (effs.length) t.effects = effs;
      if (l.fx.stroke) { t.strokes = [{ type: "SOLID", color: rgb01(l.fx.stroke.color) }]; t.strokeWeight = Math.max(0.5, l.fx.stroke.size); t.strokeAlign = "OUTSIDE"; }
      if (l.fx.gradientOverlay && l.fx.gradientOverlay.stops && l.fx.gradientOverlay.stops.length >= 2) {
        const g = l.fx.gradientOverlay;
        const stops = g.stops.map((s3) => ({ position: s3.pos, color: { ...rgb01(s3.color), a: 1 } }));
        if (g.reverse) stops.forEach((s3) => (s3.position = 1 - s3.position));
        stops.sort((a, b) => a.position - b.position);
        const rad2 = ((g.angle || 90) - 90) * Math.PI / 180;
        const c2 = Math.cos(rad2), s4 = Math.sin(rad2);
        t.fills = [{ type: "GRADIENT_LINEAR", gradientStops: stops,
          gradientTransform: [[c2, s4, (1 - c2 - s4) / 2], [-s4, c2, (1 + s4 - c2) / 2]] }];
      }
    }
    if (font.substituted) ctx.substitutions.add((l.text.font || "?") + " → " + font.family);
    node = t;
  } else if (l.kind === "fill") {
    const r = figma.createRectangle();
    parent.appendChild(r);
    r.x = l.x; r.y = l.y;
    r.resize(Math.max(1, l.w), Math.max(1, l.h));
    if (l.gradient && l.gradient.stops && l.gradient.stops.length >= 2) {
      const stops = l.gradient.stops.map((s) => ({ position: Math.min(1, Math.max(0, s.pos)), color: { ...rgb01(s.color), a: 1 } }));
      if (l.gradient.reverse) stops.forEach((s) => (s.position = 1 - s.position));
      stops.sort((a, b) => a.position - b.position);
      const rad = ((l.gradient.angle || 90) - 90) * Math.PI / 180;
      const c = Math.cos(rad), s2 = Math.sin(rad);
      r.fills = [{ type: "GRADIENT_LINEAR", gradientStops: stops,
        gradientTransform: [[c, s2, (1 - c - s2) / 2], [-s2, c, (1 + s2 - c) / 2]] }];
    } else {
      r.fills = [{ type: "SOLID", color: rgb01(l.fill || { r: 128, g: 128, b: 128 }) }];
    }
    r.name = l.name || "칠 레이어";
    node = r;
  } else if (l.kind === "shape" && l.fill && !ctx.images.has(l.imageKey)) {
    const r = figma.createRectangle();
    parent.appendChild(r);
    r.x = l.x; r.y = l.y;
    r.resize(Math.max(1, l.w), Math.max(1, l.h));
    r.fills = [{ type: "SOLID", color: rgb01(l.fill) }];
    r.name = l.name || "셰이프";
    node = r;
  } else if (l.imageKey && ctx.images.has(l.imageKey)) {
    const bytes = ctx.images.get(l.imageKey);
    const img = figma.createImage(bytes);
    const r = figma.createRectangle();
    parent.appendChild(r);
    r.x = l.x; r.y = l.y;
    r.resize(Math.max(1, l.w), Math.max(1, l.h));
    r.fills = [{ type: "IMAGE", imageHash: img.hash, scaleMode: "FILL" }];
    r.name = l.name || "이미지";
    if (l.isMask) r.isMask = true;
    node = r;
  }
  if (node) {
    if (l.liveBlur && "effects" in node) node.effects = [...(node.effects || []), { type: "LAYER_BLUR", radius: l.liveBlur, visible: true }];
    if (typeof l.opacity === "number" && l.opacity < 1) node.opacity = l.opacity;
    if (l.kind !== "group" && l.blend && BLEND[l.blend]) node.blendMode = BLEND[l.blend];
    if (l.hidden) node.visible = false;
  }
  ctx.count++;
  if (ctx.count % 10 === 0) figma.ui.postMessage({ type: "progress", done: ctx.count, total: ctx.total });
  return node;
}

figma.ui.onmessage = async (msg) => {
  try {
    if (msg.type === "import-begin") {
      pending = { spec: msg.spec, options: msg.options, images: new Map() };
      figma.ui.postMessage({ type: "ready-for-images" });
    } else if (msg.type === "image") {
      if (pending) pending.images.set(msg.key, msg.bytes);
    } else if (msg.type === "import-run") {
      if (!pending) return;
      const { spec, options, images } = pending;
      const ctx = { images, options, count: 0, total: spec.totalLayers || 0, substitutions: new Set() };
      // 배치 위치: 기존 콘텐츠 오른쪽
      let baseX = 0;
      for (const n of figma.currentPage.children) baseX = Math.max(baseX, n.x + n.width + 100);
      const created = [];
      for (const board of spec.boards) {
        const frame = figma.createFrame();
        frame.name = board.name + "  · v1.8";
        frame.resize(spec.canvas.width, spec.canvas.height);
        frame.x = baseX; frame.y = 0;
        baseX += spec.canvas.width + 100;
        frame.clipsContent = true;
        frame.fills = [{ type: "SOLID", color: { r: 1, g: 1, b: 1 } }];
        figma.currentPage.appendChild(frame);
        for (const child of board.children || []) await buildLayer(child, frame, ctx);
        created.push(frame.id);
      }
      figma.viewport.scrollAndZoomIntoView(await Promise.all(created.map(id => figma.getNodeByIdAsync(id))));
      figma.ui.postMessage({ type: "done", frames: created.length, substitutions: [...ctx.substitutions] });
      pending = null;
    } else if (msg.type === "resize") {
      figma.ui.resize(380, msg.height);
    }
  } catch (e) {
    figma.ui.postMessage({ type: "error", message: String(e && e.message ? e.message : e) });
  }
};
